#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
// Taimoor Shaukat 24i-3015 SE-B Q1 PF A1 , used setw and left allignment aswell as moving spaces between backslashs,slashes,dashes and brackets to cout the text art
int main()
{
    cout << setw(12) << left << "  ____                _     _          _            ____     _                 _                _                       " << endl;
    cout << setw(12) << left << " / ___|              |  \\  | |        | |          |  __ \\  | |               ( )              ( )                      " << endl;
    cout << setw(12) << left << "| (___   __ _  _   _ |   \\ | |   ___  | |_    ___  | |__) | | |  _  _   __  _  _   __ _  _ __   _     __  _ __ __       " << endl;
    cout << setw(12) << left << " \\___ \\ / _` || | | ||    -  |  / _ \\ | __|  / _ \\ |  __ /  | | / _` | / _` || | / _` || '_ \\ | |  / _` || '_ ` _ \\     " << endl;
    cout << setw(12) << left << "  ___) || (_| || |_| || -     | | (_) || |_  | (_) || |      | || (_| || (_| || || (_| || | | || |  (_| || | | | | |    " << endl;
    cout << setw(12) << left << " |____/ \\__,_| \\__,_||_|  \\__|  \\___/  \\__|  \\___/ |_|      |_| \\__,_| \\__,_||_| \\__,_||_| |_||_|  \\__,_||_| |_| |_|    " << endl;
    cout << setw(12) << left << "                __/ |                                                   __/  |                                          " << endl;
    cout << setw(12) << left << "               |___/                                                   |___ /                                           " << endl;
}

