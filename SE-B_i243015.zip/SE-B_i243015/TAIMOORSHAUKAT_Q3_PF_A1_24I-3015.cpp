#include <iostream>
#include <math.h>
using namespace std;
//TAIMOOR SHAUKAT 24i-3015 SE-B Q3 PF A1
int main()
{
	int amount,hu,fif,ten;
	cout<<"enter amount to be withdrawn"<<endl;
	cin>>amount;
	//ENTER THE AMOUNT TO BE WITHDRAWN
	hu = (amount>=100)?amount/100:0;
	amount=amount-(hu*100);
	//IF THE AMOUNT IS MORE THEN OR EQUAL TO HUNDRED DIVDE IT BY HUNDRED AND STORE THAT VALUE OR ELSE STORE ZERO IN NUMBER OF HUNDRED RS NOTES
	//SUBTRACT THE VALUE OF TOTAL HUNDRED RS NOTES FROM THE INTIAL AMOUNT TO UPDATE IT
	fif =(amount>=50)?amount/50:0;
	amount=amount-(fif*50);
	//IF THE AMOUNT IS MORE THEN OR EQUAL TO FIFTY DIVDE IT BY FIFTY AND STORE THAT VALUE OR ELSE STORE ZERO IN NUMBER OF FIFTY RS NOTES
	//SUBTRACT THE VALUE OF TOTAL FIFTY RS NOTES FROM THE  AMOUNT TO UPDATE IT
	ten =(amount>=10)?amount/10:0;
	amount=amount-((amount/10)*10);
	//IF THE AMOUNT IS MORE THEN OR EQUAL TO 10 DIVDE IT BY 10 AND STORE THAT VALUE OR ELSE STORE ZERO IN NUMBER OF 10 RS NOTES
	//SUBTRACT THE VALUE OF TOTAL TEN RS NOTES FROM THE  AMOUNT TO UPDATE IT
	cout<<hu<<" "<<"hundred Rs notes"<<endl;
	cout<<fif<<" "<<"fifty Rs notes"<<endl;
	cout<<ten<<" "<<"ten Rs notes"<<endl;
	//OUTPUT THE NUMBER OF NOTES NEEDED OF EACH TYPE
	return 0;

}