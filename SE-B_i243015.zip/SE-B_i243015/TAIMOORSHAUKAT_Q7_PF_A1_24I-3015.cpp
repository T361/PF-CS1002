#include <iostream>
#include <string>
#include <math.h>
using namespace std;
int main()
{
	//TAIMOOR SHAUKAT 24I-3015 SE-B Q7 PF A1
	long double marks1,credit_hours1,gp1,marks2,credit_hours2,gp2,marks3,credit_hours3,gp3,marks4,credit_hours4,gp4,marks5,credit_hours5,gp5,N,D,GPA;
	string grade1,grade2,grade3,grade4,grade5,z;
	
	cout<<"enter marks or number less then equal to 49 for none"<<endl;
	cin>>marks1;
	cout<<"enter credit hours or 0 if none"<<endl;
	cin>>credit_hours1;
	//HERE ASKING USER TO ENTER CREDIT HOURS AND MARKS FOR SUBJECT AND IF THERE IS NOT A SUBJECT THEN USER ENTERS LESS THAN 49 FOR MARKS AND 0 IN CREDIT HOURS
	grade1 = (marks1>=90)?"A+":
	(90>marks1>=86)?"A":
	(86>marks1>=82)?"A-":
	(82>marks1>=78)?"B+":
	(78>marks1>=74)?"B":
	(74>marks1>=70)?"B-":
	(70>marks1>=66)?"C+":
	(66>marks1>=62)?"C":
	(62>marks1>=58)?"C-":
	(58>marks1>=54)?"D+": 
	(54>marks1>=50)?"D":"F";
	
	gp1 = (grade1=="A+")?4.0:
	(grade1=="A")?4.0:
	(grade1=="A-")?3.67:
	(grade1=="B+")?3.33:
	(grade1=="B")?3.00:
	(grade1=="B-")?2.67:
	(grade1=="C+")?2.33:
	(grade1=="C")?2.00:
	(grade1=="C-")?1.67:
	(grade1=="D+")?1.33:
	(grade1=="D")?1.00:0.00;
	// HERE I USED NESTED TENERAY OPERATOR TO ASSIGN A GRADE TO THE SUBJECT THROUGH THE MARKS OBTAINED
	// THEN THROUGH THE ASSIGNED GRADE I DETERMINED AND ASSIGNED A GRADE POINT TO THE SUBJECT WHICH IS ALSO DONE THROUGH NESTED TENERAY OPERATORS
	//AS WITHIN THE SEMI COLONS OF A TENERY OPERATOR ENTIRE LINES OF CODE CAN BE WRITTEN
	
	cout<<"enter marks or number less then equal to 49 for none"<<endl;
	cin>>marks2;
	cout<<"enter credit hours or 0 if none"<<endl;
	cin>>credit_hours2;
	grade2 = (marks2>=90)?"A+":
	(90>marks2>=86)?"A":
	(86>marks2>=82)?"A-":
	(82>marks2>=78)?"B+":
	(78>marks2>=74)?"B":
	(74>marks2>=70)?"B-":
	(70>marks2>=66)?"C+":
	(66>marks2>=62)?"C":
	(62>marks2>=58)?"C-":
	(58>marks2>=54)?"D+": 
	(54>marks2>=50)?"D":"F";
	
	gp2 = (grade2=="A+")?4.0:
	(grade2=="A")?4.0:
	(grade2=="A-")?3.67:
	(grade2=="B+")?3.33:
	(grade2=="B")?3.00:
	(grade2=="B-")?2.67:
	(grade2=="C+")?2.33:
	(grade2=="C")?2.00:
	(grade2=="C-")?1.67:
	(grade2=="D+")?1.33:
	(grade2=="D")?1.00:0.00;
	
	cout<<"enter marks or number less then equal to 49 for none"<<endl;
	cin>>marks3;
	cout<<"enter credit hours or 0 if none"<<endl;
	cin>>credit_hours3;
	
	grade3 = (marks3>=90)?"A+":
	(90>marks3>=86)?"A":
	(86>marks3>=82)?"A-":
	(82>marks3>=78)?"B+":
	(78>marks3>=74)?"B":
	(74>marks3>=70)?"B-":
	(70>marks3>=66)?"C+":
	(66>marks3>=62)?"C":
	(62>marks3>=58)?"C-":
	(58>marks3>=54)?"D+": 
	(54>marks3>=50)?"D":"F";
	
	gp3 = (grade3=="A+")?4.0:
	(grade3=="A")?4.0:
	(grade3=="A-")?3.67:
	(grade3=="B+")?3.33:
	(grade3=="B")?3.00:
	(grade3=="B-")?2.67:
	(grade3=="C+")?2.33:
	(grade3=="C")?2.00:
	(grade3=="C-")?1.67:
	(grade3=="D+")?1.33:
	(grade3=="D")?1.00:0.00;

	cout<<"enter marks or number less then equal to 49 for none"<<endl;
	cin>>marks4;
	cout<<"enter credit hours or 0 if none"<<endl;
	cin>>credit_hours4;
	
	grade4 = (marks2>=90)?"A+":
	(90>marks4>=86)?"A":
	(86>marks4>=82)?"A-":
	(82>marks4>=78)?"B+":
	(78>marks4>=74)?"B":
	(74>marks4>=70)?"B-":
	(70>marks4>=66)?"C+":
	(66>marks4>=62)?"C":
	(62>marks4>=58)?"C-":
	(58>marks4>=54)?"D+": 
	(54>marks4>=50)?"D":"F";
	
	gp4 = (grade4=="A+")?4.0:
	(grade4=="A")?4.0:
	(grade4=="A-")?3.67:
	(grade4=="B+")?3.33:
	(grade4=="B")?3.00:
	(grade4=="B-")?2.67:
	(grade4=="C+")?2.33:
	(grade4=="C")?2.00:
	(grade4=="C-")?1.67:
	(grade4=="D+")?1.33:
	(grade4=="D")?1.00:0.00;
	
	cout<<"enter marks or number less then equal to 49 for none"<<endl;
	cin>>marks5;
	cout<<"enter credit hours or 0 if none"<<endl;
	cin>>credit_hours5;
	grade5 = (marks5>=90)?"A+":
	(90>marks5>=86)?"A":
	(86>marks5>=82)?"A-":
	(82>marks5>=78)?"B+":
	(78>marks5>=74)?"B":
	(74>marks5>=70)?"B-":
	(70>marks5>=66)?"C+":
	(66>marks5>=62)?"C":
	(62>marks5>=58)?"C-":
	(58>marks5>=54)?"D+": 
	(54>marks5>=50)?"D":"F";
	gp5 = (grade5=="A+")?4.0:
	(grade5=="A")?4.0:
	(grade5=="A-")?3.67:
	(grade5=="B+")?3.33:
	(grade5=="B")?3.00:
	(grade5=="B-")?2.67:
	(grade5=="C+")?2.33:
	(grade5=="C")?2.00:
	(grade5=="C-")?1.67:
	(grade5=="D+")?1.33:
	(grade5=="D")?1.00:0.00;
	// THEN THE INTIAL CODE IS REPEATED MANUALLY BY ASKING FOR EACH OF THE 5 SUBJECTS WITHOUT THE USE OF LOOPS OR CONDITIONS
	
	N = (gp1*credit_hours1)+(gp2*credit_hours2)+(gp3*credit_hours3)+(gp4*credit_hours4)+(gp5*credit_hours5);
	D = credit_hours1+credit_hours2+credit_hours3+credit_hours4+credit_hours5;
	GPA = N/D;
	//HERE THE SUM OF THE PRODUCTS OF EACH GRADE POINT WITH ITS CREDIT HOURS IS STORED IN N
	// AND THE SUM OF THE TOTAL CREDIT HOURS OF EACH SUBJECT COMBINED ARE STORED ASWELL IN D
	// THEN THE TWO ARE DIVIDED TO OBTAIN THE GPA

	z=(GPA==4.00)?"CONGRATULATION YOUR NAME HAS BEEN PLACED ON RECTOR LIST OF HONOR":
	(GPA>3.50)?"CONGRATULATIONS YOUR NAME HAS BEEN PLACED ON DEAN'S LIST OF HONOR":
	(GPA<2.00)?"YOUR NAME HAS BEEN PLACED ON WARNING LIST":"THIS IS YOUR GPA";
	// HERE THE SUITABLE MESSAGE FOR EACH CASE IS STORED AS A STRING IN Z
	
	cout<<z<<endl;
	cout<<GPA;
	//HERE THE MESSAGE ALONG WITH THE STUDENTS GPA IS DISPLAYED

	return 0;
} 
