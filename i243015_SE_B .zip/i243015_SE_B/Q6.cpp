#include <iostream>
#include <string>
using namespace std;
int main(){
	//TAIMOOR SHAUKAT , 24I-3015 , ASSIGNMENT 2
	int yrs,rate,ovrt,dep,reg,bo;
	double sal,bbo,obo,dbo,la,hbo,fbo;
	string depart,regi;
	cout<<" What are the years of service of the employee"<<endl;
	cin>>yrs;
	while(yrs<3)
	{
		cout<<"Employee does not qualify for bonus, enter again"<<endl;//TAKES INPUT AND VALIDATES IT THE CATEGORY OF YEARS OF SERVICE THE EMPLOYEE HAS GIVEN
		cin>>yrs;
	}
	switch(((yrs>=3)&&(yrs<5)?1:((yrs>=5)&(yrs<10))?2:(yrs>10)?3:0))//changing years into a single int to make switch case more efficent
	{
		case 1:
			yrs =1;
			break;
		case 2:
			yrs = 2;
			break;
		case 3 :
			yrs = 3;
			break;
		default:
			yrs = 0;
	}
	cout<<"enter employees performance rating  between 1 to 5"<<endl;
	cin>>rate;
	while((rate<0 ) || (rate>5))
	{
		cout<<"invalid enter again"<<endl;//TAKES INPUT OF EMPLOYEE RATING AND VALIDATES IT
		cin>>rate;
	}
	cout<<"enter number of overtime hours"<<endl;
	cin>>ovrt;
	while(ovrt<0)
	{
		cout<<"invalid enter again"<<endl;//TAKES INPUT OF THE CATEGORY OF OVERTIME HOURS THE EMPLOYEE HAS PUT IN AND VALIDATES IT
		cin>>ovrt;
	}
	switch(((ovrt>100)&&(ovrt<200))?1:(ovrt>200)?2:0) //breakdown of ovrt into single into to make it easier for further switch satements
	{
		case 1:
			ovrt = 1;
			break;
		case 2:
			ovrt = 2;
			break;
		default:
			ovrt =3;
			break;		
	}
	cout<<"What department is employee from? Engineering,Sales,Other ?"<<endl;
	cin>>depart;
	while((depart!="Engineering")&&(depart!="Sales")&&(depart!="Other"))
	{
		cout<<"invalid, enter again"<<endl;//TAKES INPUT OF EMPLOYEES DEPARTMENT AND VALIDATES IT
		cin>>depart;
	}
	switch((depart=="Engineering")?1:(depart=="Sales")?2:3)
	{
		case 1:
			dep =1;
			break;
		case 2:
			dep=2;
			break;
		default:
			dep = 3;
			break;
	}
	cout<<"what is employees region? RegionA, RegionB , Other ? "<<endl;
	cin>>regi;
	while((regi!="RegionA")&&(regi!="RegionB")&&(regi!="Other"))
	{
		cout<<"invalid, enter again"<<endl;//TAKES INPUT OF EMPLOYEE REGIONS AND VALIDATES IT
		cin>>regi;
	}
	switch((regi=="RegionA")?1:(regi=="RegionB")?2:3)//takes an int to the corresponding location to simplify for next switch statements
	{
		case 1:
			reg =1;
			break;
		case 2:
			reg = 2;
			break;
		case 3:
			reg =3;
			break;
	}
	cout<<"enter employees annual salary"<<endl;
	cin>>sal;
	while(sal<0)
	{
		cout<<"invalid enter again"<<endl;// TAKES INPUT OF EMPLOYEES SALARY AND VALIDATES IT
		cin>>sal;
	}
	switch(((yrs==1)&&(rate==5)?1:((yrs==1)&&(rate==4))?2:((yrs==1)&&(rate==3))?3:((yrs==2)&&(rate==5))?4:((yrs==2)&&(rate==4))?5:((yrs==2)&&(rate==3))?6:((yrs==3)&&(rate==5))?7:((yrs==3)&&(rate==4))?8:((yrs==3)&&(rate==3))?9:0))
	{// CHECKS CATEGORY OF YEARS SERVED AND PERFORMANCE RATING TO CALCULATE BASE BONUS
		case 1:
			bbo= sal*0.1;
			break;
		case 2:
			bbo = sal*0.07;
			break;
		case 3:
			bbo = sal*0.05;
			break;
		case 4:
			bbo = sal*0.15;
			break;
		case 5:
			bbo = sal*0.10;
			break;
		case 6:
			bbo = sal*0.08;
			break;
		case 7:
			bbo = sal*0.2;
			break;
		case 8:
			bbo = sal*0.15;
			break;
		case 9:
			bbo = sal*0.12;
			break;
		default:
			bbo = 0;
			break;
	}
	switch(((ovrt==1)&&(rate==5))?1:((ovrt==2)&&(rate==5))?2:(ovrt==1)?3:(ovrt==2)?4:0)
	{//CHECKS CATEGORY OF OVERTIME HOURS AND PERFORMANCE RATING TO CALCULATE OVERTIME BONUS
		case 1:
			obo = (sal*0.01) + (sal*0.02);
			break;
		case 2:
			obo = (sal*0.01) + (sal*0.04);
			break;
		case 3:
			obo =  (sal*0.02);
			break;
		case 4:
			obo = (sal*0.04);
			break;
		default:
			obo = 0;
			break;
	}
	switch(dep)
	{//CHECKS DEPARTMENT AND CALCULATES DEPARTMENT BONUS ACCORDINGLY
		case 1:
			dbo = sal*0.05;
			break;
		case 2:
			dbo = sal*0.03;
			break;
		default:
			dbo = 0;
			break;
	}
	switch(reg)
	{//CHECKS LOCATION WHERE EMPLOYEES WORKING IN AND CALCULATES LOCATION ALLOWANCE
		case 1:
			la = sal*0.05;
			break;
		case 2:
			la = sal*0.03;
			break;
		default:
			la = 0;
	}
	switch((sal>100000)?1:0)
	{//CHECKS SALARY IS ELIGIBLE FOR HIGH SALARY BONUS AND CALCULATES IT ACCORDING TO ALL THE PREVIOUS BONUSES CALCULATED UPTILL NOW
		case 1:
			hbo = (la+bbo+obo+dbo)*0.05;
			break;
		default:
			hbo = 0;
			break;
	}
	fbo = hbo + la + bbo + obo + dbo;// ADDS UP FINAL BONUS
	cout<<"BASE BONUS:  "<<bbo<<endl;// NEXT LINES OUTPUT EACH INDIVIDUAL TYPE OF BONUS AND HIGH SALARY BONUS IF EMPLOYEE IS ELGIBLE
	cout<<"OVERTIME BONUS:   "<<obo<<endl;// AS WELL AS FINAL BONUS AMOUNT AFTER ADDING ALL TYPES OF BONUS
	cout<<"DEPARTMENT BONUS:  "<<dbo<<endl;
	cout<<"LOCATION ALLOWANCE:  "<<la<<endl;
	switch((hbo>0)?1:0)
	{
		case 1:
			cout<<"HIGH SALARY BONUS BASED ON ALL PREVIOUS BONUSES COMBINED :     "<<hbo<<endl;
			break;
		default:
			cout<<"No high salary bonus  "<<endl;
	}
	cout<<"FINAL BONUS:   "<<fbo<<endl;
	return 0;	
}
