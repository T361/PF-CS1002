#include <iostream>
using namespace std;
int main(){
	// TAIMOOR SHAUKAT , 24I-3015 , ASSIGNMENT 2
	int n1,n2,n3,n4,n5,max,i=1,j,imax;
	//TAKING INPUT FOR VALUES OF ALL FIVE BAR CHARTS AND VERIFYING THEM ALL
	cout<<"enter value for 1st bar chart"<<endl;
	cin>>n1;
	while(n1<0)
	{
		cout<<"invalid enter again"<<endl;
		cin>>n1;
	}
	cout<<"enter value for 2nd bar chart"<<endl;
	cin>>n2;
	while(n2<0)
	{
		cout<<"invalid enter again"<<endl;
		cin>>n2;
	}
	cout<<"enter value for 3rd bar chart"<<endl;
	cin>>n3;
	while(n3<0)
	{
		cout<<"invalid enter again"<<endl;
		cin>>n3;
	}
	cout<<"enter value for 4th bar chart"<<endl;
	cin>>n4;
	while(n4<0)
	{
		cout<<"invalid enter again"<<endl;
		cin>>n4;
	}
	cout<<"enter value for 5th bar chart"<<endl;
	cin>>n5;
	while(n5<0)
	{
		cout<<"invalid enter again"<<endl;
		cin>>n5;
	}
	cout<<"          "<<endl;
	//FINDING THE HIGHEST VALUE AMONG THE 5 BAR CHARTS IN THE NEXT LINES
	max = n1;
	if(n2>max)
	{
		max = n2;
	}
	if (n3>max)
	{
		max = n3;
	}
	if(n4>max)
	{
		max = n4;
	}
	if(n5>max)
	{
		max = n5;
	}
	imax = max;//STORING THE MAXIMUM VALUE IN A SEPERATE VARIABLE
	while(i<=imax)//LOOPING UNTIL THE BIGGEST VALUE OF THE THREE BARCHARTS,TO MOVE TO EACH INDIVIDUAL ROW IN THE BAR GRAPH GRID AND ITS PARTICULAR ROW
	{
		j=1;
		if(max>=10)//IF CURRENT MAXIMUM VALUE IS LESS THAN 10 THEN ADDING A 0 NEXT TO IT IN THE FOLLOWING LINES
		{
			cout<<max<<" ";
		}
		else if(max<10)
		{
			cout<<"0"<<max<<" ";
		}
		while(j<=i)//LOOPS TO ADD EITHER A BLANK OR A STAR EACH INDIVIDUAL COLUMN OF ONE PARTICULAR ROW IN THE BAR GRAPH GRID
		{
			if(max!=n1)
			{                   
				cout<<"  ";//ADD TWO SPACES IF THE CURRENT ROW VALUE I.E THE CURRENT MAXIMUM BAR GRAPH VALUE CORRESPONDS TO THE VALUE OF THE BAR GRAPH COLUMN THE CURSOR IS ON
			}
			else if(max==n1)
			{
				cout<<"* ";
				n1 = n1 -1; //ADD A STAR AND ONE SPACE IF THE CURRENT ROW VALUE I.E THE CURRENT MAXIMUM BAR GRAPH VALUE CORRESPONDS TO THE VALUE OF THE BAR GRAPH COLUMN THE CURSOR IS ON
			}// THEN DECREMENT THE MAX BAR GRAPH VALUE THE CURSOR WAS ON
			//REPEAT THIS LOGIC FOR ALL BAR GRAPHS
			if(max!=n2)
			{
				cout<<"  ";
			}
			else if(max==n2)
			{
				cout<<"* ";
				n2 = n2 -1;
			}
			
			if(max!=n3)
			{
				cout<<"  ";
			}
			else if(max==n3)
			{
				cout<<"* ";
				n3 = n3 -1;
			}
			
			if(max!=n4)
			{
				cout<<"  ";
				
			}
			else if(max==n4)
			{
				cout<<"* ";
				n4 = n4 -1;
			}
			
			if(max!=n5)
			{
				cout<<"  ";
				
			}
			else if(max==n5)
			{
				cout<<"* ";
				n5 = n5 -1;
			}
			
			j++; //inner loops done first completely,TO EVENTUALLY STOP IT AND MOVE TO NEXT ROW ON BAR GRAPH GRID
		}
		cout<<endl;//GOING TO THE NEXT ROW
		max = max -1;//DECREMENT THE VALUE OF CURRENT MAXIMUM GRAPH VALUE TO CORRESPOND TO THE NEXT ROW WE ARE ON NOW
		i++;//outside loop then done once
	}
	cout<<"   1 2 3 4 5"<<endl;
}
