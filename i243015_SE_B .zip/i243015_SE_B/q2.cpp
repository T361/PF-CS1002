#include <iostream>
using namespace std;
// TAIMOOR SHAUKAT 24I-3015 BSE-1B q2 assignment 3
int lift_operating_system(int,int,char);
char halt_lift(char);
char un_halt_lift(char);
int liftup(int,int);
int liftdown(int,int);
int liftdown(int current_floor,int requested_floor){
	current_floor = requested_floor;
	return current_floor;
}
int liftup(int current_floor,int requested_floor){
	current_floor = requested_floor;
	return current_floor;
}
char halt_lift(char status){
	status = 'H';
	return status;
}
char un_halt_lift(char status){
	status = 'W';
	return status;
}
int lift_operating_system(int requested_floor,int current_floor,char lift_status){
	int ch=999;
	while(ch!=5)
	{
		//lifts current info
		cout<<"enter choice"<<endl;
		cout<<"lift status"<<lift_status<<endl;
		cout<<"current floor"<<current_floor<<endl;
		cin>>ch;
		if(ch==1)
		{
			
			if(current_floor<5 && lift_status=='W')//LIFT GOING UP VALIDATION CHECKS
			{
				lo:
					cout<<"what floor do you want to go up to"<<endl;
					cin>>requested_floor;
				if(current_floor<requested_floor && (current_floor>=-1 && current_floor<=5) ){
					current_floor = liftup(current_floor,requested_floor);
					cout<<"currrent floor"<<current_floor<<endl;
				}
				else
					{
						cout<<"invalid"<<endl;
						goto lo;
					}
				
			}
			else
			{
				cout<<"lift cant move "<<endl;	
			}	
		}
		else if(ch==2)
		{
			if(lift_status !='H')//HALTING VALIDATION CHECKS
			{
				lift_status = halt_lift(lift_status);
				cout<<"lift halted"<<endl;	
			}
			else
			{
				cout<<"lift already halted"<<endl;
			}
		}
		else if(ch==3)
		{
			if(current_floor>-1 && lift_status=='W')//LIFT GOING DOWN VALIDATION CHECKS
			{
				l:
					cout<<"what floor do you want to go down to"<<endl;
					cin>>requested_floor;
				if((current_floor>requested_floor) && (current_floor>-1 && current_floor<5) ){
					current_floor = liftdown(current_floor,requested_floor);
					cout<<"currrent floor"<<current_floor<<endl;
				}
				else
					{
						cout<<"invalid"<<endl;
						goto l;
					}
				
			}
			else
			{
				cout<<"lift cant move "<<endl;	
			}	
		}
		else if(ch==4)//LIFT UNHALTING VALIDATION CHECKS
		{
			if(lift_status !='W')
			{
				lift_status = un_halt_lift(lift_status);
				cout<<"lift unhalted"<<endl;	
			}
			else
			{
				cout<<"lift already unhalted"<<endl;
			}
		}
		else if(ch==5)
		{
			cout<<"exit elevator"<<endl;
		}
		else
		{
			cout<<"incorrect option"<<endl;
		}
		
	}
}
int main(){
	int current_floor=-1,requested_floor=-1;
	char lift_status = 'W';
	cout<<"hit 1 to go up to a floor"<<endl;
	cout<<"hit 2 to halt lift"<<endl;
	cout<<"hit 3 to go down to a floor"<<endl;
	cout<<"hit 4 to unhalt lift"<<endl;
	cout<<"hit 5 to exit"<<endl;
	while(true){//endless loop calling lift os infintely
		lift_operating_system(requested_floor,current_floor,lift_status);
	}
}
