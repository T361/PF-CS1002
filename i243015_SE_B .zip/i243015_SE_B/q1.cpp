#include <iostream>
// TAIMOOR SHAUKAT , 24i-3015 , BSE-1B q1 assignment 3
using namespace std;
int Calculate_length(string);
bool substring(string main,string str);
int substring_position(string main,string str);
int Calculate_length(string s){
	int count=0;
	for (char c: s)//loop runs till number of characters in string s as string is an array of characters
	{
		count = count+1;//counting of chars in string
	}
	return count;// RETURNS LENGTH OF STRING
	
}
bool substring(string main,string str)
{
	char currentchar;
	int theword,thesentence;
	theword = Calculate_length(str);
	thesentence = Calculate_length(main);
	for(int i=0; i<thesentence-theword;i++)// loops till max index where str could be
	{	
		bool found=true;
		for(int j=0;j<theword;j++)
		{
			currentchar = main[i+j];//grabs each char of main in this loop and checks it against each char of str to see if it matches or not
			if(currentchar != str[j])
			{
				found = false;
				break;
			}
		}
		if(found)
		{
			return found;
		}
	}
	return false;
}
int substring_position(string main,string str)
{
	char currentchar;
	int prevstr=0;
	int theword,thesentence;
	theword = Calculate_length(str);
	thesentence = Calculate_length(main);
	if(substring(main,str)==0)
	{
		return -1;
	}
	else if(substring(main,str)==1)// checks if the substring even exists in the main str
	{
				
		for(int i=0; i<thesentence-theword;i++)
		{	
			bool found=true;
			for(int j=0;j<theword;j++)
			{
				currentchar = main[i+j];
				if(currentchar != str[j])
				{
					found = false;
					break;
				}
			}
			prevstr = prevstr +1;// checks for till where the string ends
			if(found)
			{
				return prevstr-1;//returns starting index of string
			}
		}
	}
}
int main(){
	string main,str;
	int ch=999,index=999;
	bool found;
	cout<<"Enter your main string"<<endl;
	getline(cin,main);
	cout<<"hit 1 to check string length"<<endl;
	cout<<"hit 2 to check if a substring is present"<<endl;
	cout<<"hit 3 to check position of a substring"<<endl;
	cin>>ch;
	cin.ignore();
	switch(ch)
	{
		case 1:
			cout<<Calculate_length(main);
			break;
		case 2:
			cout<<"enter substring"<<endl;
			cin>>str;
			found=substring(main,str);
			if(found)
			{
				cout<<"substring present in it"<<endl;
			}
			else
			{
				cout<<"substring not present in it"<<endl;
			}
			break;
		case 3:
			cout<<"enter substring"<<endl;
			cin>>str;
			index=substring_position(main,str);
			if(index==-1)
			{
				cout<<"substring not present in it"<<endl;
			}
			else
			{
				cout<<"substring starting position"<<index<<endl;
			}
			break;
		default:
			break;
	}
}
