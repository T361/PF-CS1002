#include <iostream>
#include <string>
using namespace std;
int main(){
	//TAIMOOR SHAUKAT , 24I-3015 , ASSIGNMENT 2
	string one ="1",two="2",three="3",four="4",five="5",six="6",seven="7",eight="8",nine="9",s1="X",s2="O";
	int p1,p2,i=0;
	cout<<" "<<one<<" "<<"|"<<" "<<two<<" "<<"|"<<" "<<three<<" "<<endl;
	cout<<"---|---|----"<<endl;
	cout<<" "<<four<<" "<<"|"<<" "<<five<<" "<<"|"<<" "<<six<<" "<<endl;	
	cout<<"---|---|----"<<endl;
 	cout<<" "<<seven<<" "<<"|"<<" "<<eight<<" "<<"|"<<" "<<nine<<" "<<endl;//displaying the intial board game
 	while(i<9)//game will end when 9 moves are played eitherway
 	{
 		cout<<"player 1 as X, please enter your move"<<endl;
 		cin>>p1;
 		while(p1<0 || p1>9)
 		{
 			cout<<"invalid enter again"<<endl;//inputting and validating player 1s moves who is X.
 			cin>>p1;
		 }
 		if(p1==1)//next lines execute player 1s moves and output the updated board game
 		{
 			one = s1;
		}
		else if(p1==2)
		{
			two = s1;
		}
		else if(p1==3)
		{
			three = s1;
		}
		else if(p1==4)
		{
			four = s1;
		}
		else if(p1==5)
		{
			five = s1;
		}
		else if(p1==6)
		{
			six = s1;
		}
		else if(p1==7)
		{
			seven = s1;
		}
		else if(p1==8)
		{
			eight = s1;
		}
		else if(p1==9)
		{
			nine = s1;
		}
			cout<<" "<<one<<" "<<"|"<<" "<<two<<" "<<"|"<<" "<<three<<" "<<endl;
			cout<<"---|---|----"<<endl;
			cout<<" "<<four<<" "<<"|"<<" "<<five<<" "<<"|"<<" "<<six<<" "<<endl;	
			cout<<"---|---|----"<<endl;
 			cout<<" "<<seven<<" "<<"|"<<" "<<eight<<" "<<"|"<<" "<<nine<<" "<<endl;
 		if((s1==seven)&&(s1==five)&&(s1==three))//next conditions check for all win conditions and if player1s moves match them
 		{
 			cout<<"PLAYER 1 WINS!!!!!"<<endl;
 			break;
		}
		else if((s1==one)&&(s1==two)&&(s1==three))
 		{
 			cout<<"PLAYER 1 WINS!!!!!"<<endl;
 			break;
		}
		else if((s1==four)&&(s1==five)&&(s1==six))
 		{
 			cout<<"PLAYER 1 WINS!!!!!"<<endl;
 			break;
		}
		else if((s1==seven)&&(s1==eight)&&(s1==nine))
 		{
 			cout<<"PLAYER 1 WINS!!!!!"<<endl;
 			break;
		}
		else if((s1==one)&&(s1==four)&&(s1==seven))
 		{
 			cout<<"PLAYER 1 WINS!!!!!"<<endl;
 			break;
		}
		else if((s1==two)&&(s1==five)&&(s1==eight))
 		{
 			cout<<"PLAYER 1 WINS!!!!!"<<endl;
 			break;
		}
		else if((s1==three)&&(s1==six)&&(s1==nine))
 		{
 			cout<<"PLAYER 1 WINS!!!!!"<<endl;
 			break;
		}
		else if((s1==one)&&(s1==five)&&(s1==nine))
 		{
 			cout<<"PLAYER 1 WINS!!!!!"<<endl;
 			break;
		}
		i++;//updates after one move by player 1 is done
		if (i==9)
		{
			break;//loop exits and game ends after 9th move
		}
			cout<<"player 2 as O ,please enter your move"<<endl;
 		cin>>p2;
 		while(p1<0 || p1>9)
 		{
 			cout<<"invalid enter again"<<endl;//inputting and validating player 2s moves who is X.
 			cin>>p2;
		 }
 		if(p2==1)//next lines execute player 2s moves and output the updated board game
 		{
 			one = s2;
		}
		else if(p2==2)
		{
			two = s2;
		}
		else if(p2==3)
		{
			three = s2;
		}
		else if(p2==4)
		{
			four = s2;
		}
		else if(p2==5)
		{
			five = s2;
		}
		else if(p2==6)
		{
			six = s2;
		}
		else if(p2==7)
		{
			seven = s2;
		}
		else if(p2==8)
		{
			eight = s2;
		}
		else if(p2==9)
		{
			nine = s2;
		}
			cout<<" "<<one<<" "<<"|"<<" "<<two<<" "<<"|"<<" "<<three<<" "<<endl;
			cout<<"---|---|----"<<endl;
			cout<<" "<<four<<" "<<"|"<<" "<<five<<" "<<"|"<<" "<<six<<" "<<endl;	
			cout<<"---|---|----"<<endl;
 			cout<<" "<<seven<<" "<<"|"<<" "<<eight<<" "<<"|"<<" "<<nine<<" "<<endl;
 		if((s2==seven)&&(s2==five)&&(s2==three))//next conditions check for all win conditions and if player2s moves match them
 		{
 			cout<<"PLAYER 2 WINS!!!!!"<<endl;
 			break;
		}
		else if((s2==one)&&(s2==two)&&(s2==three))
 		{
 			cout<<"PLAYER 2 WINS!!!!!"<<endl;
 			break;
		}
		else if((s2==four)&&(s2==five)&&(s2==six))
 		{
 			cout<<"PLAYER 2 WINS!!!!!"<<endl;
 			break;
		}
		else if((s2==seven)&&(s2==eight)&&(s2==nine))
 		{
 			cout<<"PLAYER 2 WINS!!!!!"<<endl;
 			break;
		}
		else if((s2==one)&&(s2==four)&&(s2==seven))
 		{
 			cout<<"PLAYER 2 WINS!!!!!"<<endl;
 			break;
		}
		else if((s2==two)&&(s2==five)&&(s2==eight))
 		{
 			cout<<"PLAYER 2 WINS!!!!!"<<endl;
 			break;
		}
		else if((s2==three)&&(s2==six)&&(s2==nine))
 		{
 			cout<<"PLAYER 2 WINS!!!!!"<<endl;
 			break;
		}
		else if((s2==one)&&(s2==five)&&(s2==nine))
 		{
 			cout<<"PLAYER 2 WINS!!!!!"<<endl;
 			break;
		}
		i++;//updates after  one move by player 2 is done 
	 }
	 cout<<"MOVES FINISHED!! GAME ENDED!"<<endl;
}
