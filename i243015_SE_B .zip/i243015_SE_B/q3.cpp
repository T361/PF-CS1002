#include <iostream>
using namespace std;
// TAIMOOR SHAUKAT , 24i-3015 , BSE-1B q3 assignment 3
#define MAX 10
void displayMatrix(int [MAX][MAX],int,int);
void multiplyMatrices(int[MAX][MAX],int[MAX][MAX],int,int,int,int);
void multiplyMatrix(int a[MAX][MAX],int b[MAX][MAX],int rowA,int colA,int rowB,int colB){
	// intialising answer matrix so no garbage values
	int ans[MAX][MAX]={{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}};
	for (int i = 0; i < rowA; i++) {             // iterate over rows of A
        for (int j = 0; j < colB; j++) {         // iterate over columns of B
            for (int k = 0; k < colA; k++) {     // iterate over elements in the row of first matrix
                ans[i][j] += a[i][k] * b[k][j];
            }
        }
    }
	cout<<"MULTIPLIED MATRIX "<<endl;
	displayMatrix(ans,rowA,colB);		
}
void displayMatrix(int matrix[MAX][MAX],int row,int col){
	for(int i=0;i<row;i++)
	{
		for(int j=0;j<col;j++)
		{
			cout<<matrix[i][j];//outputting 2-d array in matrix format
			cout<<" ";
		}
		cout<<endl;
	}
}
int main(){
	int a[MAX][MAX];
	int b[MAX][MAX];
	int rowA,rowB,colA,colB;
	mismatch:
	meow:
	cout<<"Enter rows of first matrix"<<endl;
	cin>>rowA;
	if(rowA<1)
	{
		cout<<"invalid enter again"<<endl;
		goto meow;
	}
	wow:
	cout<<"Enter columns of first matrix"<<endl;
	cin>>colA;
	if(colA<1)
	{
		cout<<"invalid enter again"<<endl;
		goto wow;
	}
	m:
	cout<<"Enter rows of second matrix"<<endl;
	cin>>rowB;
	if(rowB<1)
	{
		cout<<"invalid enter again"<<endl;
		goto m;
	}
	mew:
	cout<<"Enter columns of second matrix"<<endl;
	cin>>colB;
	if(colB<1)
	{
		cout<<"invalid enter again"<<endl;
		goto mew;
	}
	if(colA != rowB)
	{
		cout<<"mismatch array sizes enter rows and cols again"<<endl;
		goto mismatch;
	}
	cout<<"enter elements in first array"<<endl;
	for(int i=0;i<rowA;i++)
	{
		for(int j=0;j<colA;j++)
		{
			cin>>a[i][j];
		}
	}
	cout<<"enter elements in second array"<<endl;
	for(int i=0;i<rowB;i++)
	{
		for(int j=0;j<colB;j++)
		{
			cin>>b[i][j];
		}
	}
	cout<<"1st matrix"<<endl;
	displayMatrix(a,rowA,colA);
	cout<<"2nd matrix"<<endl;
	displayMatrix(b,rowB,colB);
	multiplyMatrix(a, b,rowA,colA,rowB,colB);
}
