#include <iostream>
using namespace std;
int main(){
	//TAIMOOR SHAUKAT , 24I-3015 , ASSIGNMENT 2
	int intialgap,currentgap,desired;
	cout<<"enter desired number of rows of pyramid "<<endl;
	cin>>desired;
	while(desired<=0)
	{
		cout<<"invalid, enter again"<<endl;// ENTERING AND VALIDATING DESIRED NUMBER OF ROWS FOR PYRAMID
		cin>>desired;
	}
	intialgap= desired - 1;//THE NUMBER OF SPACES FOR THE FIRST ROW OF THE PYRAMID TO BE MADE
	for(int i=1,k=0;i<=desired;i++,k=0)// USED TO MOVE AND MAKE THE ENTIRE PYRAMID OF ROWS
	{
		for(int gaps=1;gaps<=desired-i;gaps++)
		{
			cout<<" ";// LOOPING TO MAKE SPACES
		}
		currentgap = desired-i;// CURRENT GAP IS THE NUMBER OF SPACES REQUIRED TO MAKE EACH INDIVIDUAL ROW
		if(i==1)
		{
			cout<<"|";//FIRST ROW ONLY CONTAINS THE SYMBOL "|" ALWAYS
		}
		else{
			for(;k!=2*i-1;k++) //bodmas used here, as multiplied here first then -1, USED TO INSERT SYMBOLS IN A INDIVIDUAL ROW
			{
				if(k==(intialgap-currentgap))//IF K REACHES THE CENTRE OF THE PYRAMID PLACE "|" SYMBOL
				{
					cout<<"|";
				}
				else if(k<(intialgap-currentgap))
				{
					cout<<"\\";// BEFORE K REACHES CENTRE OF PYRAMID PLACE "\", ONLY PLACED THROUGH DOUBLE BACKSLASHES
				}
				else if(k>(intialgap-currentgap))
				{
					cout<<"/";// AFTER K REACHES AND GOES BEYOND CENTRE OF PYRAMID , PLACE "/" SYMBOLS
				}
			}
		}
		cout<<endl;//FOR THE CURSOR TO GO TO NEXT ROW AFTER EACH LOOP
	}
} 
