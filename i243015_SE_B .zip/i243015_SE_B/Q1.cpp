#include <iostream>
using namespace std;
int main(){
	//TAIMOOR SHAUKAT , 24I-3015 , ASSIGNMENT 2
	int eggs;
	cout<<"Enter total number of eggs:"<<endl;
	cin>>eggs;
	while(eggs<0)
	{
		cout<<"invalide input, enter again"<<endl;// VALIDATING THAT NUMBER OF EGGS MUST ALWAYS BE POSITIVE
		cin>>eggs;
	}
	cout<<"Number of 30 eggs packing:"<<eggs/30<<" "; // DIVIDING THE NUMBER OF EGGS BY THE TYPE OF PACKING TO OBTAIN HOW MANY PACKS 
	cout<<"Number of leftover eggs: "<<eggs-((eggs/30)*30)<<endl;// MULTIPLYING THE PREVIOUS NUMBER OF PACKS WITH THE TYPE OF PACK AND SUBTRACTING IT FROM TOTAL EGGS TO OBTAIN THE LEFTOVER
	// REPEATING THE PREVIOUS LOGIC TO ALL OTHER TYPES OF PACKS
	cout<<"Number of 24 eggs packing:"<<eggs/24<<" ";
	cout<<"Number of leftover eggs: "<<eggs-((eggs/24)*24)<<endl;
	
	cout<<"Number of 18 eggs packing:"<<eggs/18<<" ";
	cout<<"Number of leftover eggs: "<<eggs-((eggs/18)*18)<<endl;
	
	cout<<"Number of 12 eggs packing:"<<eggs/12<<" ";
	cout<<"Number of leftover eggs: "<<eggs-((eggs/12)*12)<<endl;
	
	cout<<"Number of 6 eggs packing:"<<eggs/6<<" ";
	cout<<"Number of leftover eggs: "<<eggs-((eggs/6)*6)<<endl;
}
