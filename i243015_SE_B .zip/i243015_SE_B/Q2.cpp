#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
int main(){
	// TAIMOOR SHAUKAT , 24I-3015 , ASSIGNMENT 2
	unsigned int s =time(0);
	srand(s);// MAKING SURE NEW NUMBERS ARE GENERATED EACH TIME PROGRAM IS RUN
	int typeop,maximumValue,random1,random2,minimumValue,ans;
	char n;
	cout<<"FOR WHICH OPERATION EXERCISE SHOULD BE GENERATED"<<endl;
	cout<<"hit 1 for addition"<<endl;
	cout<<"hit 2 for subtraction"<<endl;
	cout<<"hit 3 for multiplication"<<endl;
	cout<<"hit 4 for divison"<<endl;
	cin>>typeop;
	while((typeop<0) || (typeop>4))
	{
		cout<<"invalid input enter again"<<endl;// ASKING WHAT TYPE OF OPERATION TO BE ENTERED AND VALIDATING IT BY WHILE LOOP
		cin>>typeop;
	}
	cout<<"What is the maximum value for the input values of the exercise?"<<endl;
	cin>>maximumValue;
	while(maximumValue == 0)
	{
		cout<<"invalid input enter again"<<endl;//ASKING WHAT WILL BE THE MAXIMUM VALUE FOR THE EXERCISE AND VALIDATING IT BY WHILE LOOP
		cin>>maximumValue;
	}
	cout<<"Are negative values allowed?  "<<endl;
	cout<<"enter Y for yes"<<endl;
	cout<<"enter N for no"<<endl;
	cin>>n;
	while((n!='Y') && (n!='N')) 
	{
		cout<<"invalid input enter again"<<endl;// ASKING HERE IF NEGATIVE VALUES ALLOWED AND VALIDATING IT BY WHILE LOOP
		cin>>n;
	}	
	if(n=='Y')
	{
		minimumValue = -1*maximumValue;
	}
	else if(n=='N')
	{
		minimumValue = 0;
	}
	random1 = (rand()%(maximumValue-minimumValue+1))+minimumValue;
	random2 = (rand()%(maximumValue-minimumValue+1))+minimumValue;//GENERATING BOTH RANDOM NUMBERS HERE

	if((typeop==2) && (n=='N'))
	{
		if (random2>random1)
		{
			do
			{
				random2 = (rand()%(maximumValue-minimumValue+1))+minimumValue;
			}while(random2>random1);//MAKING SURE IF NEGATIVE NUMBERS ARE ALLOWED AND SUBTRACTION IS CHOSEN,THEN THE SECOND NUMBER IS ALWAYS SMALLER THAN THE FIRST
		}
	}	
	if(typeop==1)//HERE ONWARDS EXCERCISES ARE GENERATED AND A MESSAGE IS GENERATED IF THEY ARE CORRECTLY OR INCORRECTLY ANSWERED
	{
		cout<<"what is "<<random1<<" "<<"+"<<" "<<random2<<" ?"<<endl;
		cin>>ans;
		if((random1+random2)==ans)
		{
			cout<<"CORRECT ANSWER!!!!!!!!!!!!!!!!!"<<endl;
		}
		else
		{
			cout<<"INCORRECT :("<<endl;
		}
	}
	else if (typeop==2)
	{
		cout<<"what is "<<random1<<" "<<"-"<<" "<<random2<<" ?"<<endl;
		cin>>ans;
		if((random1-random2)==ans)
		{
			cout<<"CORRECT ANSWER!!!!!!!!!!!!!!!!!"<<endl;
		}
		else
		{
			cout<<"INCORRECT :("<<endl;
		}
	}
	else if(typeop==3)
	{
		cout<<"what is "<<random1<<" "<<"*"<<" "<<random2<<" ?"<<endl;
		cin>>ans;
		if((random1*random2)==ans)
		{
			cout<<"CORRECT ANSWER!!!!!!!!!!!!!!!!!"<<endl;
		}
		else
		{
			cout<<"INCORRECT :("<<endl;
		}
	}
	else if(typeop==4)
	{
		cout<<"what is "<<random1<<" "<<"/"<<" "<<random2<<" ?"<<endl;
		cin>>ans;
		if((random1/random2)==ans)
		{
			cout<<"CORRECT ANSWER!!!!!!!!!!!!!!!!!"<<endl;
		}
		else
		{
			cout<<"INCORRECT :("<<endl;
		}
	}
	
}
